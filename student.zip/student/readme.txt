For this project, I chose to only align with the known genes, as I was unsure about the running time if I applied the algorithm and its implementation for the entire genome. The algorithm was as follows:

1. Find each isoform for each gene, record the start/end positions in the whole genome, save sequence of isoform

2. Match the read with each isoform
2a. Each read is split into seeds of length 15, every 6 positions from 0
2b. Each seed is then matched using the exact match algorithm from part I of the project
2c. Each seed that matched with a isoform sequence greater than a cut-off (10) was saved. 16 was chosen as 50/3 ~ 17. This means that if the match was split into 3 pieces, then it should still be detectable

3. The isoforms were then sorted against the number of saved matches, as the higher the number of saved matches, the more likely it is a good alignment

4. Take the seed matches and find correct alignment (extend seeds)
4a. Potential start indexes are found in isoform by looking for other seed alignments that may match
4b. Naive matching used to confirm match and check for how many substitutions
4c. If number of substitutions <= 6, then return positions in genome