""" 
	RNA Alignment Assignment
	
	Implement each of the functions below using the algorithms covered in class.
	You can construct additional functions and data structures but you should not
	change the functions' APIs.

	You will be graded on the helper function implementations as well as the RNA alignment, although
	you do not have to use your helper function.
	
	*** Make sure to comment out any print statement so as not to interfere with the grading script
"""

import sys # DO NOT EDIT THIS
from shared import *

ALPHABET = [TERMINATOR] + BASES

MATCH_SAVE_CUTOFF = 5



def get_suffix_array(s):
	"""
	Naive implementation of suffix array generation (0-indexed). You do not have to implement the
	KS Algorithm. Make this code fast enough so you have enough time in Aligner.__init__ (see bottom).

	Input:
		s: a string of the alphabet ['A', 'C', 'G', 'T'] already terminated by a unique delimiter '$'
	
	Output: list of indices representing the suffix array

	>>> get_suffix_array('GATAGACA$')
	[8, 7, 5, 3, 1, 6, 4, 0, 2]
	"""
	sort_array = []
	for i in range(0, len(s)):
		new = s[i:len(s)]
		new += '$' * (i)
		new += str(i)
		sort_array += [new]

	sorted_array = sorted(sort_array)
	out = []
	for i in sorted_array:
		out += [int(i[len(s):])]
	return out



def get_bwt(s, sa):
	"""
	Input:
		s: a string terminated by a unique delimiter '$'
		sa: the suffix array of s

	Output:
		L: BWT of s as a string
	"""
	out = ""
	for i in sa:
		if i == 0:
			out += '$'
		else:
			out += s[i-1]
	return out

def get_F(L):
	"""
	Input: L = get_bwt(s)

	Output: F, first column in Pi_sorted
	"""
	return ''.join(sorted(L))

def get_M(F):
	"""
	Returns the helper data structure M (using the notation from class). M is a dictionary that maps character
	strings to start indices. i.e. M[c] is the first occurrence of "c" in F.

	If a character "c" does not exist in F, you may set M[c] = -1
	"""
	d = {}
	d['$'] = 0
	d["A"] = -1
	d["C"] = -1
	d["T"] = -1
	d["G"] = -1
	for i in range(1, len(F)):
		if F[i] != F[i-1]:
			d[F[i]] = i
	return d

def get_occ(L):
	"""
	Returns the helper data structure OCC (using the notation from class). OCC should be a dictionary that maps 
	string character to a list of integers. If c is a string character and i is an integer, then OCC[c][i] gives
	the number of occurrences of character "c" in the bwt string up to and including index i
	"""
	d = {}
	d['$'] = []
	d['A'] = []
	d['C'] = []
	d['G'] = []
	d['T'] = []
	s = 0
	a = 0
	c = 0
	g = 0
	t = 0
	for l in L:
		if l == '$':
			s += 1
		elif l == 'A':
			a += 1
		elif l == "C":
			c += 1
		elif l == "G":
			g += 1
		elif l == "T":
			t += 1
		d['$'] += [s]
		d['A'] += [a]
		d['C'] += [c]
		d['G'] += [g]
		d['T'] += [t]
	return d

def exact_suffix_matches(p, M, occ):
	"""
	Find the positions within the suffix array sa of the longest possible suffix of p 
	that is a substring of s (the original string).
	
	Note that such positions must be consecutive, so we want the range of positions.

	Input:
		p: the pattern string
		M, occ: buckets and repeats information used by sp, ep

	Output: a tuple (range, length)
		range: a tuple (start inclusive, end exclusive) of the indices in sa that contains
			the longest suffix of p as a prefix. range=None if no indices matches any suffix of p
		length: length of the longest suffix of p found in s. length=0 if no indices matches any suffix of p

		An example return value would be ((2, 5), 7). This means that p[len(p) - 7 : len(p)] is
		found in s and matches positions 2, 3, and 4 in the suffix array.

	>>> s = 'ACGT' * 10 + '$'
	>>> sa = get_suffix_array(s)
	>>> sa
	[40, 36, 32, 28, 24, 20, 16, 12, 8, 4, 0, 37, 33, 29, 25, 21, 17, 13, 9, 5, 1, 38, 34, 30, 26, 22, 18, 14, 10, 6, 2, 39, 35, 31, 27, 23, 19, 15, 11, 7, 3]
	>>> L = get_bwt(s, sa)
	>>> L
	'TTTTTTTTTT$AAAAAAAAAACCCCCCCCCCGGGGGGGGGG'
	>>> F = get_F(L)
	>>> F
	'$AAAAAAAAAACCCCCCCCCCGGGGGGGGGGTTTTTTTTTT'
	>>> M = get_M(F)
	>>> sorted(M.items())
	[('$', 0), ('A', 1), ('C', 11), ('G', 21), ('T', 31)]
	>>> occ = get_occ(L)
	>>> type(occ) == dict, type(occ['$']) == list, type(occ['$'][0]) == int
	(True, True, True)
	>>> occ['$']
	[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
	>>> exact_suffix_matches('ACTGA', M, occ)
	((1, 11), 1)
	>>> exact_suffix_matches('$', M, occ)
	((0, 1), 1)
	>>> exact_suffix_matches('AA', M, occ)
	((1, 11), 1)
	"""
	# L = [""] * len(occ['$'])
	# for k in occ.keys():
	# 	arr = occ[k]
	# 	for i in range(0, len(arr) - 1):
	# 		if arr[i] != arr[i+1]:
	# 			L[i+1] = k
	# L[0] = '$'
	l = 0
	v = p[len(p) - 1]
	SP = M[v]
	EP = 0
	if v == "$":
		EP = 0
	elif v == "A":
		EP = M["C"] - 1
	elif v == "C" or EP == -2:
		EP = M["G"] - 1
	elif v == "G" or EP == -2:
		EP = M["T"] - 1
	else:
		EP = len(occ['$']) - 1
	if SP < 0:
		return (None, 0)
	oSP = SP
	oEP = EP
	while SP <= EP and l < len(p):
		oSP = SP
		oEP = EP
		l += 1
		v = p[len(p) - l - 1]
		SP = M[v] + occ[v][SP - 1]
		EP = M[v] + occ[v][EP] - 1
	return ((oSP, oEP + 1), l)


#Gives the index matches, saves in the form: [INDEX, LENGTH]
def locate_suffix_matches_helper(p, M, occ, sa):
	saved_matches = []
	matches = exact_suffix_matches(p, M, occ)
	if matches[1] >= MATCH_SAVE_CUTOFF:
		for i in range(matches[0][0], matches[0][1]):
			saved_matches += [[sa[i], matches[1]]]
	return saved_matches
"""
	for m in matches:
		if m[1] >= MATCH_SAVE_CUTOFF:
			print (m[0])
			for i in range(m[0][0], m[0][1]):
				saved_matches += [[sa[i], m[1]]]
	return saved_matches
"""
		

#Split read into seeds
#calculate number of matches in each Suffix Array
#outputs a list of [index of read, index of reference gene data, length]
def locate_suffix_matches(p, M, occ, sa):
	matches = []
	i = 0
	while i + 8 < len(p):
		match = locate_suffix_matches_helper(p[i:i+8], M, occ, sa)
		for m in match:
			matches += [[i, m[0], m[1]]]
		i += 3
	return matches

#takes the values as below, and outputs start indexes of potential matches
def find_match_helper(val, transc, p, pos):
	starts = []
	for v in sorted(val, key=lambda x: x[1]):
		for s in starts:
			if v[1] < s[0] + 50:
				s[1] = v[1] + v[2] - s[0]
		starts += [[v[1] - v[0], v[2]]]
	for s2 in starts:
		if s2[1] > 30:
			mis = []
			l = 0
			while len(mis) <= 6 and l < 50:
				if len(transc) <= s2[0] + l:
					while l < 50:
						mis += [l]
						l += 1
					break;
				if p[l] != transc[s2[0] + l]:
					mis += [l]
				l += 1
			if len(mis) <= 6:
				result = []
				for counter in range(0, len(pos)):
					num = pos[counter]
					start2 = s2[0]
					if start2 < num[1] - num[0]:
						l2 = 0
						cont = False
						new_add = []
						while l2 < 50:
							if l2 in mis:
								if new_add:
									result += [(new_add[0], new_add[1] + s2[0], new_add[2] + 1)]
								cont = False
							elif not cont:
								new_add = [l2, num[0] + l2, 0]
								cont = True
							else:
								new_add[2] = new_add[2] + 1

							l2 += 1
						result += [(new_add[0], new_add[1] + s2[0], new_add[2] + 1)]
						return result
					else:
						start2 - (num[1] - num[0])
	return []

	

#input: suffix array, matches data from locate_suffix_matches
def find_match(p, sa, val, transc, pos):
	d = {}
	for v in val:
		diff = v[1] - v[0]
		d.setdefault(diff, [])
		d[diff] += [v]
	# print (d)
	for k in sorted(d.keys(), key=lambda x: len(d[x]), reverse=True):
		starts = find_match_helper(d[k], transc, p, pos)
		if starts:
			return starts
	return []



MIN_INTRON_SIZE = 20
MAX_INTRON_SIZE = 10000

class Aligner:
	def __init__(self, genome_sequence, known_genes):
		"""
		Initializes the aligner. Do all time intensive set up here. i.e. build suffix array.

		genome_sequence: a string (NOT TERMINATED BY '$') representing the bases of the of the genome
		known_genes: a python set of Gene objects (see shared.py) that represent known genes. You can get the isoforms 
					 and exons from a Gene object

		Time limit: 500 seconds maximum on the provided data. Note that our server is probably faster than your machine, 
					so don't stress if you are close. Server is 1.25 times faster than the i7 CPU on my computer

		"""
		self.gene_suffix_arrays = []
		self.gene_M = []
		self.gene_occ = []
		self.transc = []
		self.position = []
		for g in known_genes:
			for i in g.isoforms:
				sequence = ""
				p = []
				for e in i.exons:
					sequence += genome_sequence[e.start:e.end]
					p += [[e.start, e.end]]
				self.position += [p]
				self.transc += [sequence]
				s_arr = get_suffix_array(sequence + '$')
				self.gene_suffix_arrays += [s_arr]
				L = get_bwt(sequence, s_arr)
				self.gene_occ += [get_occ(L)]
				self.gene_M += [get_M(get_F(L))]


	def align(self, read_sequence):
		"""
		Returns an alignment to the genome sequence. An alignment is a list of pieces. 
		Each piece consists of a start index in the read, a start index in the genome, and a length 
		indicating how many bases are aligned in this piece. Note that mismatches are count as "aligned".

		Note that <read_start_2> >= <read_start_1> + <length_1>. If your algorithm produces an alignment that 
		violates this, we will remove pieces from your alignment arbitrarily until consecutive pieces 
		satisfy <read_start_2> >= <read_start_1> + <length_1>

		Return value must be in the form (also see the project pdf):
		[(<read_start_1>, <reference_start_1, length_1), (<read_start_2>, <reference_start_2, length_2), ...]

		If no good matches are found: return the best match you can find or return []

		Time limit: 0.5 seconds per read on average on the provided data.
		"""
		# Align to gene_suffix_arrays
		d = {}
		for i in range(0, len(self.gene_suffix_arrays)):
			result = locate_suffix_matches(read_sequence, self.gene_M[i], self.gene_occ[i], self.gene_suffix_arrays[i])
			if len(result) != 0:
				if len(result) not in d.keys():
					d[len(result)] = []
				d[len(result)] += [[result, self.gene_suffix_arrays[i], i]]
		for k in sorted(d.keys(), reverse=True):
			for obj in d[k]: #d[k] is a single value from result
				i = obj[2]
				n = find_match(read_sequence, self.gene_suffix_arrays[i], obj[0], self.transc[i], self.position[i])
				if n:
					starting_index = n[0][1]
					return n
		return []

		# Align to Genome





		# Align using seeds
